Tested With:

- Agda master (2.6.0), github.com/agda/agda,    commit  a2f5b8ef8176d0b6c2e7677d10c5a0617d9de8bf

- agda/cubical master, github.com/agda/cubical, commit  6aa317159b274215033e531574c0b33ff1bde148
